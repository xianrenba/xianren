<?php
$lang["slogan"] = "Remove the borders";
$lang["wikipedia"] = "Wikipedia";
$lang["back"] = "Back";
$lang["go"] = "Go";
$lang["home"] = "Home";
$lang["tos"] = "Enter here your Terms of Service text";
$lang["agree"] = "Remove the borders";
$lang["tos_2"] = "terms of use";