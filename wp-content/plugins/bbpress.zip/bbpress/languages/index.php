<?php

/**
 * Do not put custom translations here. They will be deleted on bbPress updates.
 *
 * Keep custom bbPress translations in /wp-content/languages/bbpress/
 */
