<?php 
get_header(); 
?>
<div class="wrapper">
    <!-- 主要内容区 -->
    <div class="container pagewrapper clr"  id="management-page">
            <?php include('navmenu.php'); ?>
            <div class="pagecontent">
            </div>
    </div>
</div>
<?php get_footer(); ?>