<?php
// themeid  请勿更改或删除，否者主题无法运行
$themeid = '1715854469148203';
// Require theme functions
require get_stylesheet_directory() . '/func/functions.php';
require get_stylesheet_directory() . '/func/functions-theme.php';
require get_stylesheet_directory() . '/func/functions-xzh.php';
require get_stylesheet_directory() . '/func/functions-video.php';

// Customize your functions


// 代码结束
?>