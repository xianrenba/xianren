<h2>贴入CSS代码：</h2>
<textarea onmouseover="this.focus();this.select();" id="code" class="tarea"></textarea>

<p>
	<button onclick="CSS('packAdv')">高级压缩</button>
	<button onclick="CSS('pack')">普通压缩</button>
	<button onclick="CSS('format')">格式化</button>
</p>

<h2 class="sitetip">获取CSS代码：</h2>
<textarea onmouseover="this.focus();this.select();" id="packer" class="tarea"></textarea>