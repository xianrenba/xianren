<?php
//支付同步回调
get_header();
?>
<div id="primary" class="content-area mar10-b" style="width:100%">
    <main id="pay" class="site-main pay-page box pos-r" style="min-height:400px">
        <div class="lm t-c entry-content">
            <?php
                echo '支付失败';
            ?>
        </div>
    </main>
</div>
<?php
get_footer();
