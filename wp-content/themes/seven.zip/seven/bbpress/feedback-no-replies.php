<?php

/**
 * No Replies Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<?php echo '
    <div class="loading-dom pos-r"><div class="lm"><i class="iconfont zrz-icon-font-wuneirong"></i><p class="mar10-t">暂无回帖</p></div></div>
'; ?>
