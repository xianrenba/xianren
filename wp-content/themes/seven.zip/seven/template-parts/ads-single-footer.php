<div class="pd10 mar10-t box">
    <?php
        $ads = zrz_get_ads_settings('single_footer');
        echo zrz_get_html_code($ads['str']); 
    ?>
</div>
