+(function($) {
    window._bd_share_config = {
        common: {
            "bdText": "",
            "bdMini": "2",
            "bdMiniList": false,
            "bdPic": "",
            "bdStyle": "0"
        },
        share: [{
            // "bdSize": "24",
            bdCustomStyle: suxingme_url.url_theme + '/includes/css/share.css'
        }]
    }
    with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = suxingme_url.url_theme + '/js/bdshare/static/api/js/share.js?cdnversion=' + ~(-new Date() / 36e5)];   
})(jQuery)