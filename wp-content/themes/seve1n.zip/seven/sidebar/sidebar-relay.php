<?php
/*
* vip，侧边栏
*/
?>
<section id="pages-2" class="widget widget_write mar10-b">
    <h2 class="widget-title l1 pd10 box-header">提示</h2>
    <div class="box">
        <ul>
            <li>
                如果您和题主有相同的境遇，可以上传至此和大家分享
            </li>
        <ul>
    </div>
</section>
