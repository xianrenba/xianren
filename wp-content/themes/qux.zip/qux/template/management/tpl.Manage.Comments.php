<?php 
get_header(); 
?>
<div id="main-wrap" style="margin:15px auto;">
    <!-- 主要内容区 -->
    <div class="container pagewrapper clr"  id="management-page">
            <?php include('navmenu.php'); ?>
            <div class="pagecontent">
            </div>
    </div>
</div>
<?php get_footer(); ?>